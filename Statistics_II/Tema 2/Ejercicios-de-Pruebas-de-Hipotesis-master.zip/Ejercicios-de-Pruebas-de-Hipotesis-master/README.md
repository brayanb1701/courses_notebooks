# Ejercicios-de-Pruebas-de-Hipotesis
Curso de Estadística II Esc de Ing de Sistemas UIS
